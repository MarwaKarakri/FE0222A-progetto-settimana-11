import { Component, OnInit } from '@angular/core';
import { Items} from '../interface/items';
import { ProductsService } from '../service/products.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {


  items: Items[] = [];
  products!:number;
  cartItem!: Items;
  itemsDetails: Items | undefined;
  sub!: Subscription;


  constructor(private router: ActivatedRoute, private productSrv: ProductsService, private http: HttpClient) {}

  ngOnInit(): void {
//mostra i prodotti e aggiunde l'id alla route

      this.sub = this.router.params.subscribe(async (params) => {
      const id = +params['id'];
      this.itemsDetails = await this.productSrv.viewProduct(id).toPromise();
      this.productSrv.viewProduct(id).subscribe((result)=>{
      this.cartItem = result;
    })
      })



  }
//aggiunge prodotti al carrello

  onaddToCart(result: Items){
    this.productSrv.addToCart(result);
    console.log(this.productSrv.items);
    this.productSrv.iconCounter();
  }


//unsubscribe

  ngOnDestroy(): void {

		this.sub.unsubscribe();
	}



  }




