export interface Items {
  id: number;
  image_url: string;
  name: string;
  price: number;
  description: string;
  active: boolean;
}
