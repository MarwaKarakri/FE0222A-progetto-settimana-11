import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Items } from '../interface/items';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

//ABBIAMO MODIFICATO IL JSON PER METTERE PRODOTTI DIVERSI

export class ProductsService {
  url = "http://localhost:4201"
  itemsDetails: Items | undefined;
  items: Items [] = [];
  subject  = new Subject<number>();
  counter = 0;

  constructor(private http: HttpClient) {}


//richiamo i prodotti dal server
  get(){
    return this.http.get<Items[]>(`${this.url}/products/`);
  }

  //mostra i prodotti
  viewProduct(id:number){
    return this.http.get<Items>(`${this.url}/products/${id}`)
  }
//aggiunge prodotti
  addToCart(item:Items){
    this.items.push(item);

  }
//counter
  iconCounter(){
    this.counter++;
    this.subject.next(this.counter);
  }

  getItems(){
    return this.items;
  }
//pulisce il carrello
  clearCart(){
    this.items.length= 0;
    this.counter = 0;
   this.subject.next(this.counter);
  }
  //fa scendere il counter

  downCounter(){
    this.counter--;
    this.subject.next(this.counter);
  }

}


