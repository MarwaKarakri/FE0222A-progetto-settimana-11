import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../service/products.service';
import { FormBuilder, FormControl, FormGroup,  Validators } from '@angular/forms';
import { Router } from "@angular/router";

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {
items = this.productSrv.getItems();
form!: FormGroup;
//qui abbiamo specificato i nomi proibiti
forbiddenNames = ["Dio", "Cazzo", "cazzo", "Puttana", "puttana", "Troia", "troia"]


  constructor( private productSrv: ProductsService, private fb: FormBuilder, private router: Router ) {}
//creiamo una funzione per impedire all'utente di creare profili con nomi proibiti
  forbiddenNamesSuperVision = (formC: FormControl) =>{
    if(this.forbiddenNames.includes(formC.value)){
      return {"forbiddenName":true};
    }else {
      return null;
    }
  }

  //Validators e aggiunta della funzione proibita
  ngOnInit(): void {
    this.form = this.fb.group({
      userInfo: this.fb.group({
        username:this.fb.control(null,[Validators.required, this.forbiddenNamesSuperVision]),
        address:this.fb.control(null,[Validators.required,this.forbiddenNamesSuperVision]),
      })
    });
  }

  getErrorsC(name: string, error: string) {
		return this.form.get(name)?.errors![error]
	}

  getFormC(name: string) {
		return this.form.get(name);
	}

  //funzione submit che invia i dati, resetta il form e pulisce il carrello
	onSubmit() {
		console.log(this.form);
		this.form.reset();
    this.productSrv.clearCart();
	}

  //elimina gli ordini nel carrello
  onDeleteItems(id: number, i:number) {
    this.items.splice(i,1);
    this.productSrv.downCounter();
  }

  //link per tornare al componente prodotti
  roadProducts(){
    this.router.navigate(['/products']);
  }



  }

