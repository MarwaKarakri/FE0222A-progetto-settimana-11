import { Component, OnInit} from '@angular/core';
import { Items } from '../interface/items';
import { ProductsService } from '../service/products.service';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

  allItems: Items[] | undefined;

  constructor(private productSrv: ProductsService) {}

  ngOnInit(): void {

//prendo i prodotti dal server

    this.productSrv.get().subscribe((allItem) => {
      this.allItems = allItem;
      console.log(this.allItems);
    })
  }
}
