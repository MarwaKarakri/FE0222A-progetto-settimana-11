import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ProductsService } from '../service/products.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  total: number = 0;

  constructor(private router: Router, private productSrv: ProductsService) {}

  ngOnInit(): void {

    //counter dei prodotti nel carrello
    //funzione richiamata tramite service

    this.productSrv.subject.subscribe((counter) =>{
      this.total = counter;
    })
  }

  //routes

roadHome() {
  this.router.navigate(['/'])
}

roadProducts(){
  this.router.navigate(['/products']);
}

roadCart(){
this.router.navigate(['/cart']);
}




}
